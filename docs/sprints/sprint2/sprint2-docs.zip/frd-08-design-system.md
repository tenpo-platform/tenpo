# FRD 8: Design System

## Token Structure

```typescript
// src/config/tokens.ts

export const tokens = {
  colors: {
    // Brand
    primary: {
      50: '#f0fdf4',
      100: '#dcfce7',
      // ... full scale from Figma
      500: '#22c55e', // Main brand color
      600: '#16a34a',
      900: '#14532d',
    },
    // Semantic
    background: {
      primary: '#ffffff',
      secondary: '#f9fafb',
      tertiary: '#f3f4f6',
    },
    text: {
      primary: '#111827',
      secondary: '#6b7280',
      tertiary: '#9ca3af',
    },
    border: {
      default: '#e5e7eb',
      focus: '#22c55e',
    },
    status: {
      success: '#22c55e',
      error: '#ef4444',
      warning: '#f59e0b',
      info: '#3b82f6',
    },
  },
  typography: {
    fontFamily: {
      sans: 'Inter, system-ui, sans-serif',
      display: 'Seriously Nostalgic, Inter, sans-serif',
    },
    fontSize: {
      xs: '0.75rem',
      sm: '0.875rem',
      base: '1rem',
      lg: '1.125rem',
      xl: '1.25rem',
      '2xl': '1.5rem',
      '3xl': '1.875rem',
      '4xl': '2.25rem',
    },
    fontWeight: {
      normal: '400',
      medium: '500',
      semibold: '600',
      bold: '700',
    },
    lineHeight: {
      tight: '1.25',
      normal: '1.5',
      relaxed: '1.75',
    },
  },
  spacing: {
    0: '0',
    1: '0.25rem',
    2: '0.5rem',
    3: '0.75rem',
    4: '1rem',
    5: '1.25rem',
    6: '1.5rem',
    8: '2rem',
    10: '2.5rem',
    12: '3rem',
    16: '4rem',
  },
  borderRadius: {
    none: '0',
    sm: '0.25rem',
    md: '0.375rem',
    lg: '0.5rem',
    xl: '0.75rem',
    full: '9999px',
  },
  shadows: {
    sm: '0 1px 2px 0 rgb(0 0 0 / 0.05)',
    md: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
    lg: '0 10px 15px -3px rgb(0 0 0 / 0.1)',
  },
};
```

## CSS Variables

```css
/* src/app/globals.css */

:root {
  /* Colors */
  --color-primary-500: #22c55e;
  --color-primary-600: #16a34a;
  /* ... etc from tokens */

  /* Typography */
  --font-sans: 'Inter', system-ui, sans-serif;
  --font-display: 'Seriously Nostalgic', 'Inter', sans-serif;

  /* Spacing uses Tailwind defaults */
}
```

## Tailwind Config

```typescript
// tailwind.config.ts

import type { Config } from 'tailwindcss';
import { tokens } from './src/config/tokens';

const config: Config = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: tokens.colors,
      fontFamily: {
        sans: [tokens.typography.fontFamily.sans],
        display: [tokens.typography.fontFamily.display],
      },
      // ... other token mappings
    },
  },
  plugins: [],
};

export default config;
```

## Base Components

### Button
```typescript
// src/components/ui/Button.tsx

interface ButtonProps {
  variant: 'primary' | 'secondary' | 'ghost' | 'danger';
  size: 'sm' | 'md' | 'lg';
  disabled?: boolean;
  loading?: boolean;
  children: React.ReactNode;
  onClick?: () => void;
  type?: 'button' | 'submit';
}

// Variants
const variants = {
  primary: 'bg-primary-500 text-white hover:bg-primary-600',
  secondary: 'bg-white border border-border-default text-text-primary hover:bg-background-secondary',
  ghost: 'bg-transparent text-text-secondary hover:bg-background-secondary',
  danger: 'bg-status-error text-white hover:bg-red-600',
};

// Sizes
const sizes = {
  sm: 'px-3 py-1.5 text-sm',
  md: 'px-4 py-2 text-base',
  lg: 'px-6 py-3 text-lg',
};
```

### Input
```typescript
// src/components/ui/Input.tsx

interface InputProps {
  label?: string;
  error?: string;
  hint?: string;
  type: 'text' | 'email' | 'password' | 'tel' | 'number' | 'date';
  // ... standard input props
}

// States
- Default: border-border-default
- Focus: border-border-focus ring-2 ring-primary-500/20
- Error: border-status-error
- Disabled: bg-background-tertiary cursor-not-allowed
```

### Card
```typescript
// src/components/ui/Card.tsx

interface CardProps {
  children: React.ReactNode;
  padding?: 'none' | 'sm' | 'md' | 'lg';
  hover?: boolean; // Add hover effect for clickable cards
}

// Base styles
'bg-white rounded-lg border border-border-default shadow-sm'

// Hover (if clickable)
'hover:shadow-md hover:border-primary-500 transition-all cursor-pointer'
```

### Badge
```typescript
// src/components/ui/Badge.tsx

interface BadgeProps {
  variant: 'default' | 'success' | 'warning' | 'error' | 'info';
  children: React.ReactNode;
}

const variants = {
  default: 'bg-background-tertiary text-text-secondary',
  success: 'bg-green-100 text-green-800',
  warning: 'bg-yellow-100 text-yellow-800',
  error: 'bg-red-100 text-red-800',
  info: 'bg-blue-100 text-blue-800',
};
```

## Layout Components

### AppShell
```typescript
// src/components/layout/AppShell.tsx

interface AppShellProps {
  children: React.ReactNode;
  header?: React.ReactNode;
  sidebar?: React.ReactNode;
  footer?: React.ReactNode;
}

// Structure
<div className="min-h-screen flex flex-col">
  {header && <header>...</header>}
  <div className="flex flex-1">
    {sidebar && <aside>...</aside>}
    <main className="flex-1">{children}</main>
  </div>
  {footer && <footer>...</footer>}
</div>
```

### DashboardLayout
```typescript
// For /organizer/* and /dashboard/* routes
// Includes sidebar navigation, header with user menu
```

### MarketingLayout
```typescript
// For public pages: /, /camps, /camps/[id]
// Includes top nav, footer
```

### AuthLayout
```typescript
// For /login, /signup, etc.
// Centered card layout, minimal chrome
```
